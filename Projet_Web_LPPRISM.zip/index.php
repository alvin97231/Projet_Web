<?php
  $AppelInclude = './include/';
  require($AppelInclude . "header.inc.html");
?>

						<section>
                <div>
                    <p>TEST</p>
                </div>
            </section>

<?php
  require($AppelInclude . "footer.inc.html");
?>
