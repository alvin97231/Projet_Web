<?php
  $AppelInclude = './include/';
  require($AppelInclude . "header.inc.html");
?>
  <section>
    <div  id = "corps_page">
      <form  action="mysuperscript.php" autocomplete="on">

          <h1> S'inscrire </h1>
          <p>
              <label for="username" class="uname" data-icon="u">Votre nom</label>
              <input id="usernamesignup" name="username" required="required" type="text" placeholder="Nom" />
          </p>
          <p>
              <label for="email" class="youmail" data-icon="e" > Votre email</label>
              <input id="emailsignup" name="email" required="required" type="email" placeholder="*******@mail.com"/>
          </p>
          <p>
              <label for="mdp1" class="youpasswd" data-icon="p">Mot de passe </label>
              <input id="passwordsignup" name="mdp1" required="required" type="password" placeholder="eg. X8df!90EO"/>
          </p>
          <p>
              <label for="mdp2" class="youpasswd" data-icon="p">Confirmez votre mot de passe </label>
              <input id="passwordsignup_confirm" name="mdp2" required="required" type="password" placeholder="eg. X8df!90EO"/>
          </p>
          <p class="signin button">
            <input type="submit" value="Sign up"/>
          </p>
      </form>
    </div>
  </section>
<?php
  require($AppelInclude . "footer.inc.html");
?>
